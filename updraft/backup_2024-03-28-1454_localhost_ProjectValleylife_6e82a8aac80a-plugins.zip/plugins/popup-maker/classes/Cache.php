<?php
/**
 * Cache class file
 *
 * @package   PUM
 * @copyright Copyright (c) 2023, Code Atlantic LLC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class PUM_Cache
 *
 * @deprecated 1.8.0
 */
class PUM_Cache extends PUM_Utils_Cache {}
